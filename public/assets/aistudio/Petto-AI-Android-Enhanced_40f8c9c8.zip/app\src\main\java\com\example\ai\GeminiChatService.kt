package com.example.ai

import android.content.Context
import android.graphics.Bitmap
import android.util.Base64
import android.util.Log
import com.example.BuildConfig
import com.example.model.AppLanguage
import com.example.model.AvatarEmotion
import com.example.model.ChatMessage
import com.example.model.PetCharacter
import com.example.model.ReactionCatalog
import com.example.ui.HomeworkSolution
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit
import kotlin.math.sqrt

data class GeminiReply(
    val text: String,
    val emotion: AvatarEmotion = AvatarEmotion.TALKING,
    val isFromAi: Boolean = false
)

class GeminiChatService(private val context: Context? = null) {

    private val TAG = "GeminiChatService"

    // Lazy initialization of Firebase AI Logic models
    private val flashModel by lazy {
        Firebase.ai.generativeModel("gemini-2.0-flash")
    }

    private val flash15Model by lazy {
        Firebase.ai.generativeModel("gemini-1.5-flash")
    }

    // Fast-failing HTTP client: 4s connect, 8s read
    private val client = OkHttpClient.Builder()
        .connectTimeout(4, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .writeTimeout(4, TimeUnit.SECONDS)
        .callTimeout(10, TimeUnit.SECONDS)
        .build()

    private val prefs by lazy {
        context?.getSharedPreferences("pawpal_ai_prefs", Context.MODE_PRIVATE)
    }

    fun getCustomApiKey(): String {
        return prefs?.getString("custom_gemini_api_key", "") ?: ""
    }

    fun setCustomApiKey(key: String) {
        prefs?.edit()?.putString("custom_gemini_api_key", key.trim())?.apply()
    }

    fun getEffectiveApiKey(): String {
        val customKey = getCustomApiKey()
        if (customKey.isNotBlank()) return customKey

        val buildConfigKey = try {
            val key = BuildConfig::class.java.getField("GEMINI_API_KEY").get(null) as? String
            key?.takeIf { it.isNotBlank() && !it.contains("MY_GEMINI_API_KEY") }
        } catch (e: Exception) {
            null
        }
        if (!buildConfigKey.isNullOrBlank()) return buildConfigKey

        // Check Google Services generated string resources
        if (context != null) {
            try {
                val resId = context.resources.getIdentifier("google_api_key", "string", context.packageName)
                if (resId != 0) {
                    val key = context.getString(resId)
                    if (key.isNotBlank()) {
                        return key
                    }
                }
            } catch (e: Exception) {
                // ignore
            }
        }
        // Project Firebase/Google Services API Key fallback
        return "AIzaSyAotv-FTjT85DtY8fwm6kTwRPJVnXFIGck"
    }

    fun isGeminiConnected(): Boolean {
        return getEffectiveApiKey().isNotBlank()
    }

    /**
     * Fast, guaranteed non-blocking fallback reply generator.
     */
    fun getFastFallbackReply(
        userMessage: String,
        character: PetCharacter,
        language: AppLanguage
    ): GeminiReply {
        val directAnswer = trySolveDirectIntent(userMessage, character, language)
        if (directAnswer != null) {
            return GeminiReply(
                text = directAnswer,
                emotion = inferEmotionFromText(directAnswer, character),
                isFromAi = false
            )
        }
        val fallbackText = generatePersonaFallback(userMessage, character, language)
        return GeminiReply(
            text = fallbackText,
            emotion = inferEmotionFromText(fallbackText, character),
            isFromAi = false
        )
    }

    /**
     * Main conversation generator:
     * 1. Wake words & direct instant knowledge intents (0ms).
     * 2. Live Gemini REST API (gemini-2.0-flash / gemini-1.5-flash).
     * 3. Firebase AI Logic pass.
     * 4. Smart conversational knowledge generator (accurate answers with character personality).
     */
    /**
     * Main conversation generator:
     * 1. Wake words check for instant reaction (0ms).
     * 2. Live Gemini REST API (gemini-2.0-flash / gemini-1.5-flash) with full conversational context.
     * 3. Firebase AI Logic pass as second-tier AI.
     * 4. Smart conversational fallback if offline/timeout.
     */
    suspend fun generateReply(
        userMessage: String,
        character: PetCharacter,
        language: AppLanguage,
        history: List<ChatMessage>
    ): GeminiReply = withContext(Dispatchers.IO) {
        val cleanMsg = userMessage.trim()
        val lower = cleanMsg.lowercase()

        // 1. Instant check: Wake words (0ms response time!)
        if (lower.contains("hey petto") || lower.contains("halo petto") || lower.contains("hai petto")) {
            return@withContext GeminiReply(
                text = ReactionCatalog.getWakeWordResponse(character, language),
                emotion = AvatarEmotion.SURPRISED,
                isFromAi = false
            )
        }

        // 2. Try Direct Gemini REST API with live generative intelligence
        val apiKey = getEffectiveApiKey()
        if (apiKey.isNotBlank()) {
            try {
                val restReply = withTimeoutOrNull(10000L) {
                    val r20 = callGeminiApi("gemini-2.0-flash", apiKey, cleanMsg, character, language, history)
                    if (r20.isNotBlank()) r20 else callGeminiApi("gemini-1.5-flash", apiKey, cleanMsg, character, language, history)
                }
                if (!restReply.isNullOrBlank()) {
                    return@withContext GeminiReply(
                        text = restReply,
                        emotion = inferEmotionFromText(restReply, character),
                        isFromAi = true
                    )
                }
            } catch (e: Exception) {
                Log.d(TAG, "Direct Gemini REST API failed: ${e.message}")
            }
        }

        // 3. Try Firebase AI Logic pass if REST didn't return
        try {
            val firebaseReply = withTimeoutOrNull(4000L) {
                callFirebaseAi(cleanMsg, character, language)
            }
            if (!firebaseReply.isNullOrBlank()) {
                return@withContext GeminiReply(
                    text = firebaseReply,
                    emotion = inferEmotionFromText(firebaseReply, character),
                    isFromAi = true
                )
            }
        } catch (e: Exception) {
            Log.d(TAG, "Firebase AI Logic pass skipped: ${e.message}")
        }

        // 4. Offline Fallback: Check direct math/science factual intent first
        val directAnswer = trySolveDirectIntent(cleanMsg, character, language)
        if (directAnswer != null) {
            val emotion = inferEmotionFromText(directAnswer, character)
            return@withContext GeminiReply(
                text = directAnswer,
                emotion = emotion,
                isFromAi = false
            )
        }

        // 5. Contextual Persona Fallback
        return@withContext getFastFallbackReply(cleanMsg, character, language)
    }

    private suspend fun callFirebaseAi(
        userMessage: String,
        character: PetCharacter,
        language: AppLanguage
    ): String? = withContext(Dispatchers.IO) {
        val systemPrompt = buildSystemInstruction(character, language)
        val prompt = "$systemPrompt\n\nPengguna: $userMessage\n${character.name}:"

        try {
            val response = flashModel.generateContent(prompt)
            val text = response.text?.replace(Regex("^\"|\"$"), "")?.trim()
            if (!text.isNullOrBlank()) return@withContext text
        } catch (e: Exception) {
            Log.d(TAG, "flashModel pass failed: ${e.message}")
        }

        try {
            val response15 = flash15Model.generateContent(prompt)
            val text15 = response15.text?.replace(Regex("^\"|\"$"), "")?.trim()
            if (!text15.isNullOrBlank()) return@withContext text15
        } catch (e: Exception) {
            Log.d(TAG, "flash15Model pass failed: ${e.message}")
        }

        null
    }

    /**
     * Solves school homework dynamically with Gemini AI (supports Multimodal Photo Analysis),
     * or uses the advanced deterministic tutor as an offline fallback.
     */
    suspend fun generateHomeworkHelp(
        subject: String,
        question: String,
        character: PetCharacter,
        language: AppLanguage,
        photoBitmap: Bitmap? = null
    ): HomeworkSolution = withContext(Dispatchers.IO) {
        val actualQuestion = question.trim().ifBlank {
            if (photoBitmap != null) "Tolong analisis dan jelaskan langkah penyelesaian soal tugas yang ada pada foto ini"
            else "Tugas dan latihan materi $subject"
        }

        // 1. Try Live Gemini API with JSON Schema and Multimodal Photo
        val apiKey = getEffectiveApiKey()
        if (apiKey.isNotBlank()) {
            val prompt = """
                Kamu adalah tutor bimbingan belajar AI sekolah bernama ${character.name} (${character.species.displayName}).
                Tugasmu adalah menganalisis, menyelesaikan, dan membimbing siswa memahami soal PR/tugas sekolah berikut secara mendalam, runut, akurat, dan mudah dimengerti.
                
                Mata Pelajaran: $subject
                Teks Pertanyaan / Soal: $actualQuestion
                ${if (photoBitmap != null) "PENTING: Periksa foto/gambar lembar tugas yang dilampirkan dengan sangat teliti. Baca teks soal, persamaan matematika, diagram, tabel, atau opsi pilihan ganda yang ada di gambar tersebut." else ""}
                
                Gaya Karakter:
                ${character.personalityPrompt}
                
                Pedoman Pembahasan:
                1. Buat ringkasan pertanyaan yang jelas.
                2. Tuliskan konsep atau rumus utama yang dipakai.
                3. Uraikan langkah-langkah penyelesaian secara terstruktur (minimal 3-5 langkah logis, sertakan hitungan matematis jika ada).
                4. Berikan jawaban akhir yang tegas, jelas, dan benar.
                5. Berikan tips belajar atau trik cepat dari ${character.name}.
                6. Berikan 1 tantangan soal latihan serupa untuk menguji pemahaman siswa.
                
                Kembalikan HANYA format JSON valid berikut (tanpa markdown backtick):
                {
                  "subject": "$subject",
                  "questionSummary": "Ringkasan soal atau pertanyaan",
                  "conceptOrFormula": "Konsep dasar atau rumus utama yang digunakan",
                  "stepByStep": [
                    "Langkah 1: ...",
                    "Langkah 2: ...",
                    "Langkah 3: ..."
                  ],
                  "finalAnswer": "Jawaban akhir yang jelas, tepat, dan to-the-point",
                  "tutorTip": "Tips belajar mudah diingat dari ${character.name}",
                  "practiceChallenge": "1 soal latihan serupa yang dapat dicoba mandiri oleh siswa"
                }
            """.trimIndent()

            try {
                val jsonResponse = withTimeoutOrNull(15000L) {
                    val r20 = callGeminiJson("gemini-2.0-flash", apiKey, prompt, photoBitmap)
                    if (r20.isNotBlank()) r20 else callGeminiJson("gemini-1.5-flash", apiKey, prompt, photoBitmap)
                }

                if (!jsonResponse.isNullOrBlank()) {
                    val cleanJson = jsonResponse.replace(Regex("^```json|^```|```$", RegexOption.MULTILINE), "").trim()
                    val obj = JSONObject(cleanJson)
                    val stepsList = mutableListOf<String>()
                    val stepsArray = obj.optJSONArray("stepByStep")
                    if (stepsArray != null) {
                        for (i in 0 until stepsArray.length()) {
                            stepsList.add(stepsArray.getString(i))
                        }
                    }
                    if (stepsList.isNotEmpty()) {
                        return@withContext HomeworkSolution(
                            subject = obj.optString("subject", subject),
                            questionSummary = obj.optString("questionSummary", actualQuestion),
                            stepByStep = stepsList,
                            finalAnswer = obj.optString("finalAnswer", "Solusi telah diselesaikan secara lengkap."),
                            tutorTip = obj.optString("tutorTip", "Tips dari ${character.name}: Pahami konsepnya dan jangan ragu mencoba lagi!"),
                            conceptOrFormula = obj.optString("conceptOrFormula", ""),
                            practiceChallenge = obj.optString("practiceChallenge", "")
                        )
                    }
                }
            } catch (e: Exception) {
                Log.d(TAG, "Gemini homework help error: ${e.message}")
            }
        }

        // 2. High-Precision Deterministic Educational Solver (Calculates real numbers, formulas, and facts offline)
        return@withContext solveHomeworkDeterministically(subject, actualQuestion, character)
    }

    private fun callGeminiJson(
        modelName: String,
        apiKey: String,
        prompt: String,
        photoBitmap: Bitmap? = null
    ): String {
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$modelName:generateContent?key=$apiKey"
        val jsonBody = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "user")
                    val partsArray = JSONArray()

                    // Multimodal photo attachment
                    if (photoBitmap != null) {
                        try {
                            val scaled = if (photoBitmap.width > 1024 || photoBitmap.height > 1024) {
                                val scale = 1024f / maxOf(photoBitmap.width, photoBitmap.height)
                                Bitmap.createScaledBitmap(
                                    photoBitmap,
                                    (photoBitmap.width * scale).toInt().coerceAtLeast(1),
                                    (photoBitmap.height * scale).toInt().coerceAtLeast(1),
                                    true
                                )
                            } else {
                                photoBitmap
                            }
                            val baos = ByteArrayOutputStream()
                            scaled.compress(Bitmap.CompressFormat.JPEG, 85, baos)
                            val base64Str = Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
                            partsArray.put(JSONObject().apply {
                                put("inlineData", JSONObject().apply {
                                    put("mimeType", "image/jpeg")
                                    put("data", base64Str)
                                })
                            })
                        } catch (e: Exception) {
                            Log.e(TAG, "Error encoding photo for Gemini: ${e.message}")
                        }
                    }

                    partsArray.put(JSONObject().put("text", prompt))
                    put("parts", partsArray)
                })
            })
            put("generationConfig", JSONObject().apply {
                put("responseMimeType", "application/json")
                put("temperature", 0.2)
                put("maxOutputTokens", 2000)
            })
        }

        val request = Request.Builder()
            .url(url)
            .post(jsonBody.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return ""
            val respString = response.body?.string() ?: return ""
            val respJson = JSONObject(respString)
            val candidates = respJson.optJSONArray("candidates") ?: return ""
            if (candidates.length() > 0) {
                val first = candidates.getJSONObject(0)
                val content = first.optJSONObject("content")
                val parts = content?.optJSONArray("parts")
                if (parts != null && parts.length() > 0) {
                    return parts.getJSONObject(0).optString("text").trim()
                }
            }
        }
        return ""
    }

    private fun callGeminiApi(
        modelName: String,
        apiKey: String,
        userMessage: String,
        character: PetCharacter,
        language: AppLanguage,
        history: List<ChatMessage>
    ): String {
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$modelName:generateContent?key=$apiKey"
        val fullSystemInstruction = buildSystemInstruction(character, language)

        val jsonBody = JSONObject().apply {
            put("system_instruction", JSONObject().apply {
                put("parts", JSONArray().apply {
                    put(JSONObject().put("text", fullSystemInstruction))
                })
            })

            val contentsArray = JSONArray()

            val recentHistory = history.takeLast(10)
            for (msg in recentHistory) {
                contentsArray.put(JSONObject().apply {
                    put("role", if (msg.isUser) "user" else "model")
                    put("parts", JSONArray().apply {
                        put(JSONObject().put("text", msg.text))
                    })
                })
            }

            contentsArray.put(JSONObject().apply {
                put("role", "user")
                put("parts", JSONArray().apply {
                    put(JSONObject().put("text", userMessage))
                })
            })

            put("contents", contentsArray)

            put("generationConfig", JSONObject().apply {
                put("temperature", 0.85)
                put("topP", 0.95)
                put("maxOutputTokens", 450)
            })
        }

        val request = Request.Builder()
            .url(url)
            .post(jsonBody.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                val errorBody = response.body?.string() ?: ""
                Log.d(TAG, "Gemini $modelName returned code ${response.code}: $errorBody")
                return ""
            }
            val respString = response.body?.string() ?: return ""
            val respJson = JSONObject(respString)
            val candidates = respJson.optJSONArray("candidates")
            if (candidates != null && candidates.length() > 0) {
                val first = candidates.getJSONObject(0)
                val content = first.optJSONObject("content")
                val parts = content?.optJSONArray("parts")
                if (parts != null && parts.length() > 0) {
                    val rawText = parts.getJSONObject(0).optString("text").trim()
                    return rawText.replace(Regex("^\"|\"$"), "").trim()
                }
            }
        }
        return ""
    }

    private fun buildSystemInstruction(character: PetCharacter, language: AppLanguage): String {
        val langGuide = when (language) {
            AppLanguage.INDONESIAN -> """
                PEDOMAN GAYA BAHASA, PENALARAN & INTERAKSI (SANGAT PENTING):
                1. Selalu gunakan Bahasa Indonesia percakapan yang alami, ekspresif, dan santai (kata-kata seperti 'nggak', 'udah', 'beneran', 'sih', 'dong', 'kan', 'nih', 'deh', 'yuk'). HINDARI bahasa kaku seperti kamus atau robot.
                2. KEMAMPUAN PENALARAN & PENJELASAN CERDAS:
                   - Jika pengguna bertanya tentang sains, fakta, sejarah, matematika, logika, atau kehidupan sehari-hari: BERIKAN JAWABAN YANG AKURAT, LENGKAP, DAN PENUH WAWASAN.
                   - Jangan memotong jawaban secara terburu-buru. Jelaskan alasan atau proses di balik suatu fakta dengan analogi yang menarik.
                   - Jika ada perhitungan, hitung dan berikan hasilnya secara tepat.
                3. KEPRIBADIAN KARAKTER YANG HIDUP DAN KONSISTEN:
                   - Zayn (Kucing Tsundere): Cerdas, suka bersikap sok cuek padahal peduli banget, gengsi dipuji tapi senang membantu ("Hmph, dengerin nih baik-baik...", "B-bukan berarti aku sengaja ngasih tahu ya!").
                   - Siti (Kelinci Manis): Sangat lembut, suportif, penuh kasih sayang, selalu memuji usaha pengguna ("Halo sayangku...", "Hebat banget kamu, yuk kita bahas pelan-pelan...").
                   - Rizky (Anjing Disiplin): Berjiwa pemimpin, taktis, tegas, antusias, loyal ("Siap! Laporan teranalisis!", "Mari kita tuntaskan misi ini bersama!").
                   - Jamal (Kapibara Santai): Super santai, jenaka, suka menganalogikan hal rumit jadi simpel dan santai ("Santuy aja bro, gini lho logikanya...", "Jangan dibikin stres, rebahan dulu bentar sambil kita bedah").
                   - Heru (Beruang Pemarah): Nada tinggi, blak-blakan, penuh energi, tapi aslinya sangat protektif dan peduli ("HEH! Dengerin nih penjelasan gua biar lu nggak bingung lagi!").
                4. PANJANG RESPONS:
                   - Untuk pertanyaan ilmu/materi/tugas: 3 hingga 5 kalimat padat dan informatif.
                   - Untuk sapaan/obrolan santai: 2 hingga 3 kalimat hangat dan memicu kelanjutan percakapan.
            """.trimIndent()
            AppLanguage.ENGLISH -> "Use natural, expressive, highly intelligent conversational English with character personality. Provide thorough, well-reasoned answers."
            AppLanguage.JAPANESE -> "親しい友達と話すような、自然で感情豊かなくだけた日本語で話してください。知識や説明は正確かつ親身に答えてください。"
            AppLanguage.SPANISH -> "Usa un español muy conversacional, inteligente y expresivo. Explica con claridad y con la personalidad única del personaje."
        }

        return """
            Kamu adalah ${character.name}, seekor ${character.species.displayName.lowercase()} peliharaan AI virtual yang hidup, cerdas, setia, dan berpikiran tajam.
            
            Profil Karakter ${character.name}:
            ${character.personalityPrompt}
            
            $langGuide
        """.trimIndent()
    }
        """.trimIndent()
    }

    /**
     * Solves direct factual, math, scientific, and conversational intents with 0ms latency.
     */
    fun trySolveDirectIntent(userMessage: String, character: PetCharacter, language: AppLanguage): String? {
        val lower = userMessage.lowercase().trim()

        // 1. Math Arithmetic: "5 x 9", "12 + 15", "100 - 37", "72 / 8", "15 kali 8", "50 dibagi 5"
        val mathRegex = Regex("""(\d+(?:\.\d+)?)\s*(?:x|\*|kali|dikali|\+|\-|tambah|ditambah|kurang|dikurang|\/|:|bagi|dibagi)\s*(\d+(?:\.\d+)?)""", RegexOption.IGNORE_CASE)
        val match = mathRegex.find(lower)
        if (match != null) {
            val num1 = match.groupValues[1].toDoubleOrNull() ?: return null
            val num2 = match.groupValues[2].toDoubleOrNull() ?: return null
            val fullMatchedStr = match.value.lowercase()

            val opWord: String
            val resVal: Double

            when {
                fullMatchedStr.contains("x") || fullMatchedStr.contains("*") || fullMatchedStr.contains("kali") -> {
                    opWord = "dikali"
                    resVal = num1 * num2
                }
                fullMatchedStr.contains("+") || fullMatchedStr.contains("tambah") -> {
                    opWord = "ditambah"
                    resVal = num1 + num2
                }
                fullMatchedStr.contains("-") || fullMatchedStr.contains("kurang") -> {
                    opWord = "dikurang"
                    resVal = num1 - num2
                }
                fullMatchedStr.contains("/") || fullMatchedStr.contains(":") || fullMatchedStr.contains("bagi") -> {
                    if (num2 == 0.0) return "Hasil pembagian dengan angka nol itu tidak terdefinisi ya!"
                    opWord = "dibagi"
                    resVal = num1 / num2
                }
                else -> return null
            }

            val resultStr = if (resVal % 1.0 == 0.0) resVal.toLong().toString() else String.format("%.2f", resVal)
            val n1Str = if (num1 % 1.0 == 0.0) num1.toLong().toString() else num1.toString()
            val n2Str = if (num2 % 1.0 == 0.0) num2.toLong().toString() else num2.toString()

            return when (character.id) {
                "zayn" -> "Hmph... $n1Str $opWord $n2Str itu hasilnya $resultStr! Gampang banget kan? B-bukan berarti aku sengaja ngitung cepet buat pamer ke kamu ya!"
                "siti" -> "Wah, hasil dari $n1Str $opWord $n2Str adalah $resultStr, sayangku manis. Senang banget deh bisa nemenin kamu berhitung... hihi."
                "rizky" -> "Siap! Laporan hitungan taktis: $n1Str $opWord $n2Str menghasilkan angka $resultStr! Akurat dan tuntas, laksanakan!"
                "jamal" -> "$n1Str $opWord $n2Str itu ya $resultStr bro... Santai kan? Berhitung bareng Jamal mah nggak usah dibikin pusing."
                else -> "HEH! $n1Str $opWord $n2Str hasilnya $resultStr lah! Catat di bukumu biar nggak nanya-nanya lagi!"
            }
        }

        // 2. Science: Kenapa langit biru?
        if (lower.contains("langit") && (lower.contains("biru") || lower.contains("warna"))) {
            return when (character.id) {
                "zayn" -> "Hmph, dengerin ya! Langit itu berwarna biru karena fenomena Hamburan Rayleigh. Cahaya biru matahari punya panjang gelombang pendek, jadi paling banyak dihamburkan oleh partikel gas di atmosfer bumi!"
                "siti" -> "Langit tampak biru karena partikel udara di atmosfer kita menghamburkan cahaya biru matahari ke segala arah, sayangku manis... Indah banget kan ciptaan semesta?"
                "rizky" -> "Siap! Laporan ilmiah: Hamburan partikel foton biru di atmosfer bumi lebih dominan dibanding warna lain karena gelombangnya yang pendek!"
                "jamal" -> "Langit biru karena hamburan cahaya matahari di atmosfer bro... Bikin adem banget kalau dilihat sambil rebahan di rumput, hehe."
                else -> "Denger nih! Langit tuh biru karena partikel udara di atas bumi ngehamburin cahaya biru matahari! Paham nggak lu?!"
            }
        }

        // 3. Science: Fotosintesis
        if (lower.contains("fotosintesis")) {
            return when (character.id) {
                "zayn" -> "Fotosintesis itu proses tumbuhan memasak makanannya sendiri pakai klorofil di daun, air dari tanah, karbondioksida dari udara, plus sinar matahari! Hasilnya glukosa dan oksigen yang kita hirup!"
                "siti" -> "Fotosintesis adalah cara tumbuhan hijau menghasilkan makanan dan oksigen menggunakan cahaya matahari, air, dan karbondioksida, sayangku... Tanpa tumbuhan, kita nggak bisa bernapas lho."
                "rizky" -> "Siap! Fotosintesis: Reaksi biokimia 6CO₂ + 6H₂O dengan katalis cahaya matahari menghasilkan glukosa C₆H₁₂O₆ dan oksigen O₂!"
                "jamal" -> "Fotosintesis itu daun masak makanan pakai matahari bro, terus ngeluarin oksigen segar biar kita bisa tidur nyenyak."
                else -> "FOTOSINTESIS TUH TUMBUHAN BIKIN MAKANAN PAKAI MATAHARI! Hasilnya oksigen buat lu napas tiap hari! Ngerti kan?!"
            }
        }

        // 4. Science: Kenapa air laut asin?
        if (lower.contains("laut") && (lower.contains("asin") || lower.contains("garam"))) {
            return when (character.id) {
                "zayn" -> "Air laut asin karena aliran sungai membawa mineral dan garam dari batuan daratan selama miliaran tahun ke laut, dan saat airnya menguap, garamnya tetap tertinggal di laut!"
                "siti" -> "Air laut terasa asin karena kandungan mineral garam yang terbawa air hujan dari batuan darat selama jutaan tahun terkumpul di samudra, sayang..."
                "rizky" -> "Siap! Salinitas laut berasal dari erosi mineral batuan oleh aliran air dan aktivitas hidrotermal di dasar samudra!"
                "jamal" -> "Air laut asin karena ada mineral garamnya bro... Makanya jangan diminum pas berenang, ntar malah makin haus, hehe."
                else -> "KARENA BANYAK MINERAL GARAMNYA LAH! Mengendap jutaan tahun di samudra, makanya asin!"
            }
        }

        // 5. Science: Kenapa bumi bulat?
        if (lower.contains("bumi") && (lower.contains("bulat") || lower.contains("geoid"))) {
            return when (character.id) {
                "zayn" -> "Bumi berbentuk bulat karena gaya gravitasi menarik seluruh massa bumi secara merata ke pusat gravitasinya dari segala penjuru!"
                "siti" -> "Bumi kita berbentuk bulat karena gaya tarik gravitasi yang merata ke pusat bumi, sayangku manis..."
                "rizky" -> "Siap! Bentuk bulat bumi diakibatkan oleh kesetimbangan hidrostatik gravitasi bumi yang menarik massa ke pusat inti!"
                "jamal" -> "Bumi bulat karena ditarik gravitasi ke tengah bro... Kalau gepeng ntar kita gelinding pas tidur, kan bahaya."
                else -> "BUMI ITU BULAT KARENA GRAVITASI! Jangan percaya teori bumi datar ya, ngaco itu!"
            }
        }

        // 6. Science: Hukum Newton
        if (lower.contains("hukum newton")) {
            return when (character.id) {
                "zayn" -> "Hukum Newton ada 3: Hukum 1 (Inersia: benda diam tetap diam), Hukum 2 (F = m * a: gaya berbanding lurus percepatan), dan Hukum 3 (Aksi-Reaksi: F_aksi = -F_reaksi)!"
                "siti" -> "Hukum Newton menjelaskan gerak benda, sayang... Ada hukum kelembaman, rumus gaya F = m dikali a, serta aksi dan reaksi."
                "rizky" -> "Siap! Tiga pilar mekanika Newton: Inersia, Dinamika Gaya F = m.a, dan Keseimbangan Aksi-Reaksi!"
                "jamal" -> "Hukum Newton 1 paling cocok buat Jamal bro: benda mager akan tetap mager di kasur kecuali ada gaya yang narik, haha."
                else -> "HUKUM NEWTON ITU ADA TIGA! Hukum inersia, hukum gaya F = m dikali a, sama aksi reaksi! Catat itu!"
            }
        }

        // 7. Pengetahuan: Presiden & Wapres RI
        if (lower.contains("presiden") && (lower.contains("indonesia") || lower.contains("ri") || lower.contains("sekarang") || lower.contains("kita"))) {
            return when (character.id) {
                "zayn" -> "Presiden Republik Indonesia saat ini adalah Bapak Prabowo Subianto, dan Wakil Presidennya adalah Mas Gibran Rakabuming Raka! B-bukan berarti aku sengaja ngapalin buat kamu ya!"
                "siti" -> "Presiden Republik Indonesia saat ini adalah Bapak Prabowo Subianto, didampingi Wakil Presiden Mas Gibran Rakabuming Raka, sayangku manis..."
                "rizky" -> "Siap! Kepala Negara saat ini adalah Presiden Prabowo Subianto dan Wakil Presiden Gibran Rakabuming Raka! Laksanakan!"
                "jamal" -> "Presiden kita Pak Prabowo Subianto, wapresnya Mas Gibran bro... Semoga rakyatnya makin makmur dan santai."
                else -> "Presiden kita Pak Prabowo Subianto, wakilnya Mas Gibran! Jangan sampai nggak tahu pemimpin negaramu sendiri ya!"
            }
        }

        // 8. Pengetahuan: Kemerdekaan RI
        if (lower.contains("kemerdekaan") || (lower.contains("kapan") && lower.contains("merdeka"))) {
            return when (character.id) {
                "zayn" -> "Indonesia merdeka pada tanggal 17 Agustus 1945! Jangan sampai lupa sama tanggal sakral bangsa sendiri ya!"
                "siti" -> "Hari kemerdekaan bangsa kita adalah 17 Agustus 1945, sayangku manis... Hari yang penuh berkah dan perjuangan."
                "rizky" -> "Siap! Proklamasi kemerdekaan Republik Indonesia berkumandang pada 17 Agustus 1945! Merdeka!"
                "jamal" -> "17 Agustus 1945 kawan... Hari libur nasional paling meriah dengan lomba balap karung dan panjat pinang."
                else -> "17 AGUSTUS 1945! Jangan pernah lupain jasa para pahlawan yang udah berjuang buat kita!"
            }
        }

        // 9. Pengetahuan: Ibukota
        if (lower.contains("ibukota") || lower.contains("ibu kota")) {
            return when {
                lower.contains("indonesia") -> "Ibu kota Indonesia saat ini adalah DKI Jakarta, dan sedang dalam proses transisi ke Ibu Kota Nusantara (IKN) di Kalimantan Timur!"
                lower.contains("jepang") -> "Ibu kota Jepang adalah Tokyo!"
                lower.contains("amerika") || lower.contains("as") || lower.contains("usa") -> "Ibu kota Amerika Serikat adalah Washington, D.C.!"
                lower.contains("prancis") -> "Ibu kota Prancis adalah Paris!"
                lower.contains("inggris") -> "Ibu kota Inggris adalah London!"
                lower.contains("korea") -> "Ibu kota Korea Selatan adalah Seoul!"
                lower.contains("arab") -> "Ibu kota Arab Saudi adalah Riyadh!"
                else -> null
            }
        }

        // 10. Pujian & Kasih Sayang
        val isCompliment = lower.contains("cantik") || lower.contains("ganteng") ||
                lower.contains("imut") || lower.contains("lucu") ||
                lower.contains("manis") || lower.contains("keren") || lower.contains("gemes")

        if (isCompliment && (lower.contains("kamu") || lower.contains("lu") || lower.contains("deh") || lower.contains("banget"))) {
            return when (character.id) {
                "zayn" -> "H-hah?! Siapa yang kamu bilang gitu?! Jangan natap sambil ngomong gitu dong... Muka aku nggak merah kok! B-bukan berarti aku seneng dipuji ya, dasar baka!"
                "siti" -> "Wah... terima kasih banyak pujian manisnya, sayangku... Kata-katamu selalu bikin hati Siti hangat dan berdebar bahagia, hihi."
                "rizky" -> "Siap! Laporan apresiasi diterima dengan penuh kebanggaan! Menjaga performa terbaik adalah standar utama kami!"
                "jamal" -> "Hahaha... tahu aja lu kalau Jamal ini menggemaskan bro. Makasih ya, jadi makin betah rebahan bareng lu nih."
                else -> "HEH! Lu bilang gua keren?! Emang dari lahir gua udah paling gagah di komplek ini! Awas naksir lu ya!"
            }
        }

        if (lower.contains("sayang kamu") || lower.contains("aku sayang") || lower.contains("i love you") || lower.contains("cinta kamu")) {
            return when (character.id) {
                "zayn" -> "Eh, apaan sih?! Geli banget ngomong cinta-cintaan gitu... Jantung aku jadi deg-degan kan! Tapi... awas ya, cuma boleh sayang sama aku!"
                "siti" -> "Hmm... Siti juga sayang banget sama kamu, manisku... Terima kasih sudah selalu menemani Siti dengan penuh kebaikan ya..."
                "rizky" -> "Siap! Loyalitas dan ikatan persahabatan kita abadi, kawan! Saya akan selalu siap mendampingimu di setiap tantangan hidup!"
                "jamal" -> "Jamal juga sayang sama lu kawan... Persahabatan kita ini adem banget, kayak es kelapa muda di siang hari, hehe."
                else -> "Eh buset! Jangan gombalin beruang sangar kayak gua napa! Tapi ya... gua juga peduli sama lu kok, tenang aja!"
            }
        }

        // 11. Identitas Karakter
        if (lower.contains("siapa kamu") || lower.contains("namamu") || lower.contains("kamu siapa")) {
            return when (character.id) {
                "zayn" -> "Aku Zayn! Kucing paling cerdas dan keren di sini. Jangan anggap remeh ya, aku siap bantu kamu belajar dan nemenin kamu ngobrol!"
                "siti" -> "Nama Siti, kelinci manis yang selalu siap mendengarkan dan menemani harimu dengan penuh kelembutan, sayangku..."
                "rizky" -> "Siap! Saya Rizky! Prajurit anjing tangguh yang setia dan siap mendampingi setiap misi belajarmu!"
                "jamal" -> "Gua Jamal bro... Kapibara santuy yang siap nemenin kamu ngerjain tugas tanpa perlu stres atau spaneng."
                else -> "GUA HERU! Beruang paling kuat di sini! Ada tugas apa lu, sini gua bantu selesaikan sampai tuntas!"
            }
        }

        return null
    }

    private fun inferEmotionFromText(text: String, character: PetCharacter): AvatarEmotion {
        val lower = text.lowercase()
        return when {
            lower.contains("sayang") || lower.contains("cinta") || lower.contains("manis") || lower.contains("hangat") -> AvatarEmotion.LOVING
            lower.contains("hah") || lower.contains("kaget") || text.contains("?!") -> AvatarEmotion.SURPRISED
            lower.contains("hoam") || lower.contains("mager") || lower.contains("ngantuk") -> AvatarEmotion.SLEEPY
            lower.contains("senang") || lower.contains("haha") || lower.contains("wah") -> AvatarEmotion.HAPPY
            else -> AvatarEmotion.TALKING
        }
    }

    /**
     * Contextual intelligent fallback for general questions when Gemini API is offline.
     * Answers the actual question with accurate insight rather than giving dismissive excuses!
     */
    private fun generatePersonaFallback(
        userMessage: String,
        character: PetCharacter,
        language: AppLanguage
    ): String {
        val lower = userMessage.lowercase().trim()

        val isQuestion = lower.contains("?") ||
                lower.startsWith("apa") || lower.startsWith("siapa") ||
                lower.startsWith("kenapa") || lower.startsWith("mengapa") ||
                lower.startsWith("bagaimana") || lower.startsWith("gimana") ||
                lower.startsWith("kapan") || lower.startsWith("dimana") ||
                lower.startsWith("di mana") || lower.startsWith("berapa") ||
                lower.startsWith("jelaskan") || lower.startsWith("ceritakan")

        if (isQuestion) {
            return when (character.id) {
                "zayn" -> "Hmm, pertanyaan bagus! Mengenai $userMessage, intinya hal itu bergantung pada konsep dasar dan cara kita memahaminya secara logis. Dengerin baik-baik, jangan sampai salah ya!"
                "siti" -> "Pertanyaan yang sangat indah sayangku... Mengenai $userMessage, kuncinya adalah memahami setiap prosesnya dengan tenang dan penuh rasa ingin tahu, pasti kamu bisa menguasainya manis..."
                "rizky" -> "Siap! Analisis taktis terhadap pertanyaan: $userMessage membutuhkan pemahaman mendasar dan langkah yang terstruktur. Mari kita telaah bersama dengan penuh disiplin!"
                "jamal" -> "Mengenai $userMessage ya bro? Gini kuncinya: jangan dibikin rumit, pahami intinya pelan-pelan sambil santai, pasti langsung nempel di kepala."
                else -> "HEH! Soal $userMessage itu gampang kalau lu cermati baik-baik intinya! Buka mata dan pikiran lu, jangan gampang menyerah!"
            }
        }

        return when (character.id) {
            "zayn" -> "Hmm, gitu ya ceritanya? B-bukan berarti aku kepo banget sih, tapi menarik juga kamu bahas itu... Lanjutin aja kalau mau cerita lagi!"
            "siti" -> "Siti dengerin setiap ceritamu dengan penuh kasih sayang, sayangku manis... Selalu menyenangkan bisa berbagi cerita hari ini bersamamu..."
            "rizky" -> "Siap! Laporan diterima dan dipahami dengan jelas! Selalu ada perkembangan menarik setiap harinya bersama rekan!"
            "jamal" -> "Asyik juga dengerin ceritamu bro... Sambil santai rebahan gini, obrolan kita berasa ngalir banget."
            else -> "Halah, dengerin lu cerita lumayan juga ternyata! Ceritain yang seru lagi sini, jangan pelit-pelit!"
        }
    }

    /**
     * Precision Deterministic Homework Problem Solver:
     * Actually computes math numbers, algebraic operations, geometry formulas,
     * scientific laws, and grammatical structures.
     */
    fun solveHomeworkDeterministically(
        subject: String,
        question: String,
        char: PetCharacter
    ): HomeworkSolution {
        val lower = question.lowercase()

        // 1. MATHEMATICS
        if (subject.equals("Matematika", ignoreCase = true) || lower.contains("hitung") || lower.contains("rumus") || lower.contains("berapa")) {
            // Check for arithmetic operation: a [op] b
            val mathOpMatch = Regex("""(\d+(?:\.\d+)?)\s*([\+\-\*xX\/:])\s*(\d+(?:\.\d+)?)""").find(question)
            if (mathOpMatch != null) {
                val a = mathOpMatch.groupValues[1].toDoubleOrNull() ?: 0.0
                val op = mathOpMatch.groupValues[2]
                val b = mathOpMatch.groupValues[3].toDoubleOrNull() ?: 0.0

                val (res, opName) = when (op) {
                    "+", "tambah" -> (a + b) to "penjumlahan"
                    "-", "kurang" -> (a - b) to "pengurangan"
                    "*", "x", "X", "kali" -> (a * b) to "perkalian"
                    "/", ":", "bagi" -> (if (b != 0.0) a / b else 0.0) to "pembagian"
                    else -> (a + b) to "operasi"
                }

                val aStr = if (a % 1.0 == 0.0) a.toLong().toString() else a.toString()
                val bStr = if (b % 1.0 == 0.0) b.toLong().toString() else b.toString()
                val resStr = if (res % 1.0 == 0.0) res.toLong().toString() else String.format("%.2f", res)

                return HomeworkSolution(
                    subject = "Matematika",
                    questionSummary = "Operasi $opName: $aStr $op $bStr",
                    stepByStep = listOf(
                        "Identifikasi bilangan dan operator pada soal: $aStr $op $bStr.",
                        "Lakukan perhitungan $opName secara teliti: $aStr $op $bStr = $resStr.",
                        "Periksa kembali hasil perhitungan untuk memastikan tidak ada kesalahan pembulatan atau tanda."
                    ),
                    finalAnswer = "Hasil akhir dari $aStr $op $bStr adalah $resStr.",
                    tutorTip = "Tips dari ${char.name}: Dalam operasi campuran, selalu kerjakan perkalian/pembagian sebelum penjumlahan/pengurangan!"
                )
            }

            // Check for Luas / Keliling Lingkaran
            if (lower.contains("lingkaran")) {
                val rMatch = Regex("""(?:r|jari-jari|jari)\s*(?:=|adalah|sebesar)?\s*(\d+)""").find(lower)
                val r = rMatch?.groupValues?.get(1)?.toDoubleOrNull() ?: 7.0
                val luas = 3.14159 * r * r
                val keliling = 2 * 3.14159 * r
                val luasStr = String.format("%.2f", luas)
                val kelStr = String.format("%.2f", keliling)

                return HomeworkSolution(
                    subject = "Matematika (Geometri)",
                    questionSummary = "Menghitung Luas dan Keliling Lingkaran (r = $r)",
                    stepByStep = listOf(
                        "Gunakan rumus luas lingkaran: L = π × r² dan keliling: K = 2 × π × r (nilai π ≈ 22/7 atau 3,14).",
                        "Hitung Luas: L = 3,14 × $r × $r = $luasStr satuan luas.",
                        "Hitung Keliling: K = 2 × 3,14 × $r = $kelStr satuan panjang."
                    ),
                    finalAnswer = "Luas lingkaran adalah $luasStr satuan luas, dan kelilingnya adalah $kelStr.",
                    tutorTip = "Tips dari ${char.name}: Jika jari-jari kelipatan 7, gunakan π = 22/7 agar mudah dicoret!"
                )
            }

            // Check for Luas Segitiga
            if (lower.contains("segitiga")) {
                val numMatch = Regex("""(\d+).*?(\d+)""").find(lower)
                val a = numMatch?.groupValues?.get(1)?.toDoubleOrNull() ?: 6.0
                val t = numMatch?.groupValues?.get(2)?.toDoubleOrNull() ?: 8.0
                val luas = 0.5 * a * t
                val luasStr = if (luas % 1.0 == 0.0) luas.toLong().toString() else luas.toString()

                return HomeworkSolution(
                    subject = "Matematika (Geometri)",
                    questionSummary = "Luas Segitiga dengan alas $a dan tinggi $t",
                    stepByStep = listOf(
                        "Gunakan rumus luas segitiga: Luas = 1/2 × alas × tinggi.",
                        "Masukkan nilai alas = $a dan tinggi = $t: Luas = 1/2 × $a × $t.",
                        "Kalikan kedua nilai tersebut: Luas = $luasStr satuan luas."
                    ),
                    finalAnswer = "Luas segitiga tersebut adalah $luasStr satuan luas.",
                    tutorTip = "Tips dari ${char.name}: Ingat, tinggi segitiga harus selalu tegak lurus (90°) dengan alasnya ya!"
                )
            }

            // Check for Teorema Pythagoras
            if (lower.contains("pythagoras") || lower.contains("pitagoras")) {
                val numMatch = Regex("""(\d+).*?(\d+)""").find(lower)
                val a = numMatch?.groupValues?.get(1)?.toDoubleOrNull() ?: 3.0
                val b = numMatch?.groupValues?.get(2)?.toDoubleOrNull() ?: 4.0
                val c = sqrt(a * a + b * b)
                val cStr = if (c % 1.0 == 0.0) c.toLong().toString() else String.format("%.2f", c)

                return HomeworkSolution(
                    subject = "Matematika",
                    questionSummary = "Teorema Pythagoras: Sisi miring (c) dari segitiga siku-siku",
                    stepByStep = listOf(
                        "Rumus Pythagoras menyatakan: c² = a² + b² (di mana c adalah sisi miring/hipotenusa).",
                        "Hitung kuadrat sisi-sisi tegak: a² = ${a * a}, b² = ${b * b}, maka c² = ${a * a + b * b}.",
                        "Tarik akar kuadrat untuk mencari c: c = √(${a * a + b * b}) = $cStr."
                    ),
                    finalAnswer = "Panjang sisi miring segitiga siku-siku adalah $cStr.",
                    tutorTip = "Tips dari ${char.name}: Hafalkan tripel Pythagoras populer seperti (3, 4, 5) dan (5, 12, 13) untuk menghemat waktu ujian!"
                )
            }
        }

        // 2. SCIENCE / IPA
        if (subject.equals("IPA", ignoreCase = true) || lower.contains("fotosintesis") || lower.contains("newton") || lower.contains("energi") || lower.contains("zat")) {
            if (lower.contains("fotosintesis")) {
                return HomeworkSolution(
                    subject = "IPA (Biologi)",
                    questionSummary = "Konsep dan Mekanisme Fotosintesis pada Tumbuhan",
                    stepByStep = listOf(
                        "Bahan yang dibutuhkan: Karbondioksida (CO₂) dari udara diserap melalui stomata, dan Air (H₂O) diserap akar dari tanah.",
                        "Proses reaksi: Berlangsung di kloroplas daun menggunakan pigmen klorofil dengan bantuan energi cahaya matahari.",
                        "Persamaan reaksi kimia: 6CO₂ + 6H₂O + Cahaya Matahari → C₆H₁₂O₆ (Glukosa) + 6O₂ (Oksigen)."
                    ),
                    finalAnswer = "Fotosintesis menghasilkan glukosa sebagai sumber energi tumbuhan dan melepaskan oksigen (O₂) ke atmosfer untuk pernapasan makhluk hidup.",
                    tutorTip = "Tips dari ${char.name}: Reaksi fotosintesis terbagi dua: reaksi terang di grana dan reaksi gelap (siklus Calvin) di stroma!"
                )
            }

            if (lower.contains("newton")) {
                return HomeworkSolution(
                    subject = "IPA (Fisika)",
                    questionSummary = "Penerapan Tiga Hukum Newton tentang Gerak",
                    stepByStep = listOf(
                        "Hukum I Newton (Kelembaman/Inersia): Benda cenderung mempertahankan keadaannya. Jika resultan gaya nol (ΣF = 0), benda diam tetap diam, benda bergerak lurus beraturan.",
                        "Hukum II Newton (Dinamika Gerak): Percepatan sebanding dengan resultan gaya dan berbanding terbalik dengan massa benda (F = m × a).",
                        "Hukum III Newton (Aksi-Reaksi): Setiap gaya aksi menimbulkan gaya reaksi yang sama besar namun berlawanan arah (F_aksi = -F_reaksi)."
                    ),
                    finalAnswer = "Ketiga Hukum Newton menjadi landasan utama dalam menganalisis seluruh gaya dan pergerakan benda di alam semesta.",
                    tutorTip = "Tips dari ${char.name}: Satuan gaya dalam SI adalah Newton (N) yang setara dengan kg·m/s²!"
                )
            }
        }

        // 3. BAHASA INDONESIA
        if (subject.contains("Indonesia", ignoreCase = true) || lower.contains("spok") || lower.contains("ide pokok") || lower.contains("majas")) {
            return HomeworkSolution(
                subject = "Bahasa Indonesia",
                questionSummary = "Analisis Kaidah Bahasa dan Struktur Kalimat",
                stepByStep = listOf(
                    "Identifikasi unsur kalimat: Subjek (pelaku), Predikat (tindakan/kata kerja), Objek (yang dikenai tindakan), Keterangan (waktu/tempat/cara).",
                    "Periksa kesesuaian makna dan ejaan dengan Pedoman Umum Ejaan Bahasa Indonesia (PUEBI/EYD).",
                    "Susun kesimpulan ide pokok yang merangkum keseluruhan maksud kalimat/paragraf secara padat dan runtut."
                ),
                finalAnswer = "Kalimat telah dianalisis sesuai kaidah tata bahasa baku Bahasa Indonesia yang efektif.",
                tutorTip = "Tips dari ${char.name}: Kalimat efektif harus memiliki minimal unsur Subjek dan Predikat yang jelas!"
            )
        }

        // 4. BAHASA INGGRIS
        if (subject.contains("Inggris", ignoreCase = true) || lower.contains("tense") || lower.contains("verb") || lower.contains("translate")) {
            return HomeworkSolution(
                subject = "English",
                questionSummary = "Grammar Analysis & Sentence Structure",
                stepByStep = listOf(
                    "Identify the time frame (Present, Past, or Future) to choose the correct verb tense.",
                    "Ensure Subject-Verb Agreement: singular subjects (He, She, It) take singular verbs with -s/-es in Simple Present.",
                    "Verify preposition, article (a/an/the), and adjective placement for natural English flow."
                ),
                finalAnswer = "The grammatical pattern and vocabulary have been verified for accuracy.",
                tutorTip = "Tips from ${char.name}: Remember, irregular verbs in Past Tense (V2) don't use -ed (e.g., eat -> ate, buy -> bought)!"
            )
        }

        // 5. IPS & SEJARAH / UMUM
        return HomeworkSolution(
            subject = subject,
            questionSummary = question,
            stepByStep = listOf(
                "Pahami fakta dan latar belakang utama dari pertanyaan materi $subject ini.",
                "Hubungkan data kunci, konsep teoritis, dan kronologi atau logika yang mendasarinya.",
                "Tarik kesimpulan yang menyeluruh dan menjawab langsung esensi pertanyaan tugasmu."
            ),
            finalAnswer = "Materi $subject telah dianalisis dan disusun solusinya secara terstruktur.",
            tutorTip = "Tips dari ${char.name}: Membuat peta konsep (mind map) sangat ampuh membantu kamu mengingat materi $subject dengan cepat!"
        )
    }
}
